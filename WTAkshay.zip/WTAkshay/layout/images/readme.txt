Its a collection of 
1) classes
2) Readymade HTML CODE
3) effects which is based on javascript/jquery

Twitter

5